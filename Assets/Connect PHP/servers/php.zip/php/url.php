﻿<?php
# Created on 1 Dec 2011
# @author: PL Young
#=======================================================================================================================

// This file serves the addresses of games and chat servers
// IMPORTANT !!! change these URLs as needed

echo '1';						      # success code
echo '|http://CHANGE_ME/main/';       # management script url
echo '|http://CHANGE_ME/game/';       # game rules script url
